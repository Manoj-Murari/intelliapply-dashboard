import React, { useState, useEffect } from 'react';
import { ChevronLeft, X, ExternalLink } from 'lucide-react';

export default function JobDetailsPanel({ job, setSelectedJob, activeProfile }) {
    const [coverLetterPrompt, setCoverLetterPrompt] = useState('');
    const [generating, setGenerating] = useState(false);

    useEffect(() => {
        setCoverLetterPrompt('');
    }, [job]);

    const generateCoverLetterPrompt = () => {
        if (!activeProfile) {
            alert("Please create a resume profile first!");
            return;
        }
        setGenerating(true);
        const prompt = `Act as a professional career coach. Write a compelling and concise cover letter for the job described below, tailored to the candidate's resume context. Highlight key skills that match the job requirements and maintain a professional, enthusiastic tone.\n\n---CANDIDATE'S RESUME CONTEXT---\n${activeProfile.resume_context}\n\n---JOB DESCRIPTION---\nTitle: ${job.title}\nCompany: ${job.company}\nDescription: ${job.description}\n---`;
        setTimeout(() => {
            setCoverLetterPrompt(prompt);
            setGenerating(false);
        }, 500);
    };

    const copyToClipboard = () => {
        const textArea = document.createElement("textarea");
        textArea.value = coverLetterPrompt;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
        alert('Prompt copied to clipboard!');
    };

    if (!job) return null;

    return (
        <div className="fixed inset-0 bg-black/30 z-20" onClick={() => setSelectedJob(null)}>
            <div className="fixed top-0 right-0 h-full w-full max-w-2xl bg-white shadow-2xl p-6 overflow-y-auto" onClick={(e) => e.stopPropagation()}>
                <div className="flex items-center justify-between pb-4 border-b">
                    <button onClick={() => setSelectedJob(null)} className="p-2 rounded-full hover:bg-slate-100"><ChevronLeft className="w-6 h-6" /></button>
                    <h2 className="text-xl font-bold text-center flex-grow">{job.title}</h2>
                    <button onClick={() => setSelectedJob(null)} className="p-2 rounded-full hover:bg-slate-100"><X className="w-6 h-6" /></button>
                </div>
                <div className="mt-4"><p className="text-lg font-semibold text-slate-700">{job.company}</p><a href={job.job_url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-sky-600 hover:underline mt-2 text-sm font-medium">View Original Post <ExternalLink className="w-4 h-4" /></a></div>
                <div className="mt-6 p-4 bg-slate-50 rounded-lg">
                    <h3 className="font-semibold mb-2">AI Analysis</h3>
                    <div className="flex items-center gap-6">
                        <div className="text-center"><p className="text-3xl font-bold text-sky-600">{(job.similarity_score * 100).toFixed(0)}%</p><p className="text-sm text-slate-500">Similarity Match</p></div>
                        <div className="text-center"><p className="text-3xl font-bold text-amber-600">{job.gemini_rating}/10</p><p className="text-sm text-slate-500">Gemini Fit Score</p></div>
                    </div>
                    <p className="mt-4 text-sm text-slate-800"><span className="font-semibold">Reason:</span> {job.ai_reason}</p>
                </div>
                <div className="mt-6">
                    <h3 className="font-semibold mb-2">AI Cover Letter Assistant</h3>
                    <button onClick={generateCoverLetterPrompt} disabled={generating} className="w-full px-4 py-2 bg-sky-600 text-white rounded-md font-semibold hover:bg-sky-700 disabled:bg-sky-300 transition">{generating ? 'Generating...' : '✨ Generate Cover Letter Prompt'}</button>
                    {coverLetterPrompt && (<div className="mt-4 p-4 border rounded-lg bg-slate-50"><h4 className="font-semibold text-md mb-2">Your Generated Prompt</h4><p className="text-xs text-slate-500 mb-2">Copy this prompt and paste it into your favorite AI chat to get your tailored cover letter.</p><div className="p-3 bg-white border rounded-md text-sm text-slate-700 max-h-48 overflow-y-auto cover-letter-content">{coverLetterPrompt}</div><button onClick={copyToClipboard} className="mt-3 w-full px-4 py-2 bg-slate-600 text-white rounded-md font-semibold hover:bg-slate-700 transition">Copy Prompt</button></div>)}
                </div>
                <div className="mt-6"><h3 className="font-semibold mb-2">Job Description</h3><div className="prose prose-sm max-w-none text-slate-700 job-description-content border-t pt-4">{job.description}</div></div>
            </div>
        </div>
    );
}
